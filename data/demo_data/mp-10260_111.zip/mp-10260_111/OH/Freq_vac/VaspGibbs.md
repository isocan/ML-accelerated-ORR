# VaspGibbs BETA

## Parameters:
 *  ncores : 1
 *  command : srun
 *  vasp : vasp_std
 *  top : 0
 *  list_atoms : ['O', 'H']
 *  ibrion : 5
 *  T : 298.15
 *  P : 101.3
 *  mol : False
 *  gen_only : True
 *  version : False

*Vibrational frequencies have been calculated, using existing files.*
> **Warning**: frequency 29 is imaginary (i*2.034014). Your structure may not be properly relaxed. Ignoring this frequency.

# Output

## System properties
|     Property     |          Value          |
| :--------------: | :---------------------: |
| DFT Total Energy |   -249.2038       eV    |
|   Temperature    |     298.15        K     |
|     Pressure     |      101.3       KPa    |

## Energy corrections
|      Type      |       Z        |     E (eV)     |    S (eV/K)    |     F (eV)     |
| :------------: | :------------: | :------------: | :------------: | :------------: |
|      ZPE       |      N/A       |    0.5107846   |      N/A       |      N/A       |
|   Electronic   |        2       |        0       |   5.97308e-05  |  -0.01780874   |
|  Vibrational   |  1.081733e+10  |    0.4988172   |   0.003664026  |   -0.593612    |

## Thermodynamic Quantities
|     Quantity      |        Value        |
| :---------------: | :-----------------: |
|     Enthalpy      |   -248.1942     eV  |
|      Entropy      |   0.00380993   eV/K |
| Gibbs Free Energy |   -249.3301     eV  |
|     G - E_dft     |   -0.1263288    eV  |
|        TS         |    1.135931     eV  |
